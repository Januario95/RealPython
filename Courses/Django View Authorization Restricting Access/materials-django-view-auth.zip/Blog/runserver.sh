#!/bin/bash

python manage.py runserver
